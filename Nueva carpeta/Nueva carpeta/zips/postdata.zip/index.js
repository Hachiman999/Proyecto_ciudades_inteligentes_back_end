const mongoose = require("mongoose");
const { Schema, model } = mongoose;

const env = require('./env');
mongoose
    //.connect( `${env.mdbhost.host} ${env.mdbhost.db}`,env.mdbhost.config )
    .connect(`${env.mdb.llave}`, env.mdb.config)
    .then((db) => console.log("conectado"))
    .catch((err) => console.log(err));

const nodeSchema = new Schema({
    NumNodo: Number,
    Longitud: Number,
    Latitud: Number,
    Bateria: Number,
    Estado: Boolean

});
const dateSchema = new Schema({
    NumNodo: Number,
    Temperatura: Number,
    Humedad: Number,
    Vel_viento: Number,
    Dir_Viento: String,
    Temperatura_agua: Number,
    Nivel_agua: Number,
    Caudal: Number,
    Flujo: Number,
    Punto_rocio: Number,
    Presion: Number,
    Nubosidad: Number,
    Fecha: String,
    Hora: String
  
  })
const Nodes = model("Nodes", nodeSchema);
const Data = model("Date", dateSchema);


exports.handler = async (event) => {
    const {
        NumNodo,
        Temperatura,
        Humedad,
        Vel_viento,
        Dir_Viento,
        Temperatura_agua,
        Nivel_agua,
        Caudal,
        Flujo,
        Punto_rocio,
        Presion,
        Nubosidad,
        Fecha,
        Hora } = event;
       var res; 
    if (typeof NumNodo === 'number'
    && typeof Temperatura === 'number'
    && typeof Humedad === 'number'
    && typeof Vel_viento === 'number'
    && typeof Dir_Viento === 'string'
    && typeof Temperatura_agua === 'number'
    && typeof Nivel_agua === 'number'
    && typeof Caudal === 'number'
    && typeof Flujo === 'number'
    && typeof Punto_rocio === 'number'
    && typeof Presion === 'number'
    && typeof Nubosidad === 'number'
    && typeof Fecha === 'string'
    && typeof Hora === 'string'
    ) {
        const newNode = new Data({
            NumNodo,
                Temperatura,
                Humedad,
                Vel_viento,
                Dir_Viento,
                Temperatura_agua,
                Nivel_agua,
                Caudal,
                Flujo,
                Punto_rocio,
                Presion,
                Nubosidad,
                Fecha,
                Hora
        });
        try {
            await newNode.save();
            const result = await Data.find({ NumNodo: NumNodo });
            res= result; 

        } catch (err) {
            console.log(chalk.red("El error es :=>") + chalk.white.bgRed(err));
        }

    }
    var respuesta={ status:200, body :res   }; 

    return respuesta; 
};
