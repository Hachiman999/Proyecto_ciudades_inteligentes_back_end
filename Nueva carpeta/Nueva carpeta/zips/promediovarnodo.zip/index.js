const mongoose = require("mongoose");
const { Schema, model } = mongoose;

const env = require('./env');
mongoose
    //.connect( `${env.mdbhost.host} ${env.mdbhost.db}`,env.mdbhost.config )
    .connect(`${env.mdb.llave}`, env.mdb.config)
    .then((db) => console.log("conectado"))
    .catch((err) => console.log(err));

const nodeSchema = new Schema({
    NumNodo: Number,
    Longitud: Number,
    Latitud: Number,
    Bateria: Number,
    Estado: Boolean

});
const dateSchema = new Schema({
    NumNodo: Number,
    Temperatura: Number,
    Humedad: Number,
    Vel_viento: Number,
    Dir_Viento: String,
    Temperatura_agua: Number,
    Nivel_agua: Number,
    Caudal: Number,
    Flujo: Number,
    Punto_rocio: Number,
    Presion: Number,
    Nubosidad: Number,
    Fecha: String,
    Hora: String

})
const Nodes = model("Nodes", nodeSchema);
const Data = model("Date", dateSchema);


exports.handler = async (event) => {
    const result = await Nodes.find({});

    const respuest = [];
    for (var i = 0; i < result.length; i++) {
        const { NumNodo } = result[i];
        const resultData = await Data.find({ NumNodo: NumNodo });
        const data_pro = {

            Temperatura: 0,
            Humedad: 0,
            Vel_viento: 0,
            Temperatura_agua: 0,
            Nivel_agua: 0,
            Caudal: 0,
            Flujo: 0,
            Punto_rocio: 0,
            Presion: 0,
            Nubosidad: 0,
        };
        for (var j = 0; j < resultData.length; j++) {
            const {

                Temperatura,
                Humedad,
                Vel_viento,
                Temperatura_agua,
                Nivel_agua,
                Caudal,
                Flujo,
                Punto_rocio,
                Presion,
                Nubosidad,
            } = resultData[i];

            data_pro.Temperatura += Temperatura;
            data_pro.Humedad += Humedad;
            data_pro.Vel_viento += Vel_viento;
            data_pro.Temperatura_agua += Temperatura_agua;
            data_pro.Nivel_agua += Nivel_agua;
            data_pro.Caudal += Caudal;
            data_pro.Flujo += Flujo;
            data_pro.Punto_rocio += Punto_rocio;
            data_pro.Presion += Presion;
            data_pro.Nubosidad += Nubosidad;
        }//fin for datos

        data_pro.Temperatura = data_pro.Temperatura / result.length;
        data_pro.Humedad = data_pro.Humedad / result.length;
        data_pro.Vel_viento = data_pro.Vel_viento / result.length;
        data_pro.Temperatura_agua = data_pro.Temperatura_agua / result.length;
        data_pro.Nivel_agua = data_pro.Nivel_agua / result.length;
        data_pro.Caudal = data_pro.Caudal / result.length;
        data_pro.Flujo = data_pro.Flujo / result.length;
        data_pro.Punto_rocio = data_pro.Punto_rocio / result.length;
        data_pro.Presion = data_pro.Presion / result.length;
        data_pro.Nubosidad = data_pro.Nubosidad / result.length;

        respuest.push({
            NumNodo: NumNodo,
            data_pro
        });

    }//fin for nodos



    const response = {
        statusCode: 200,
        body: respuest,
    };
    return response;
};
